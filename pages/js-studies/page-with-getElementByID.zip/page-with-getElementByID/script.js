document.getElementById("header-h1").innerHTML = "Meu hobby favorito: Video games"

// ------------- profile --------------

document.getElementById("my-name").innerHTML = "Felype Nascimento"
document.getElementById("my-photo").src = "images/profilePicture.jpg"
document.getElementById("age").innerHTML = "25 anos"
document.getElementById("state").innerHTML = "São Gonçalo - Rio de Janeiro"

// ------------- descrição geral -------------

document.getElementById("main-h2").innerHTML = "Video games"
document.getElementById("main-paragraph").innerHTML = "Olá! Vou falar um pouco do meu hobby favorito: jogos virtuais e minha história com isso :D"

// ------------- primeira sessão-------------

document.getElementById("first-section-h3").innerHTML = "Megadrive III"
document.getElementById("megadrive-photo").src = "images/megadrive.webp"
document.getElementById("megadrive-description").innerHTML = "Bom, esse foi o meu primeiro video game, ganhei quando tinha uns 6~7 anos. Minha mãe acabou esquecendo ele dentro de um ônibus quando voltávamos pra casa. :( Joguei jogos como Mortal Kombat, Sonic, Alex Kidd, Altered Beast e outros"

// ------------- segunda sessão-------------

document.getElementById("second-section-h3").innerHTML = "Gameboy Color"
document.getElementById("gameboy-photo").src = "images/gameboy.jpg"
document.getElementById("gameboy-description").innerHTML = "Esse foi meu primeiro e único console portátil. Aos 12 anos, mais ou menos, um primo de 312º grau (não sei ao certo) me deu o dele porque tinha acabado de ganhar um Nintendo DS. Joguei Pokemon Red, Tony Hawk, Dragon Ball e Perfect Dark. Foi difícil jogar, não pela dificuldade dos jogos, mas porque como esse 'primo' é italiano, os jogos eram em italiano hahaha"

// ------------- terceira sessão-------------

document.getElementById("third-section-h3").innerHTML = "Playstation 1"
document.getElementById("ps1-photo").src = "images/ps1.jpg"
document.getElementById("ps1-description").innerHTML = "Esse foi o console que eu mais joguei, eu acho. Ganhei pouco tempo antes de ganhar o gameboy. Joguei jogos como Final Fantasy Tactics, Crash, Warcraft 2, Tekken 3, Legend of Legaia, Legend of Mana, etc. Minha avó sempre me levava pra comprar jogos por 5 reais na feira."

// ------------- quarta sessão -------------

document.getElementById("fourth-section-h3").innerHTML = "Playstation 2"
document.getElementById("ps2-photo").src = "images/ps2.jpg"
document.getElementById("ps2-description").innerHTML = "O play 2 foi um divisor de águas, foi o segundo mais jogado nessa lista. Foi o que eu mais joguei com amigos. Jogos como God of War, Naruto Shippudden, Final Fantasy X, GTA: San Andreas fizeram parte dessa época. "

// ------------- quinta sessão -------------

document.getElementById("fifth-section-h3").innerHTML = "Xbox 360"
document.getElementById("xbox360-photo").src = "images/xbox360.webp"
document.getElementById("xbox360-description").innerHTML = "O Xbox 360 foi na verdade pro meu irmão mais novo, eu já nem jogava mais video game quando meu pai comprou esse pra ele, então joguei bem pouco, mas foi bem legal pois foi o primeiro console que eu joguei mais com meu irmão e nos aproximamos bastante com isso."

